
def handler(*args):
    """handler says hello"""
    del args
    print "Hello from lambda"
